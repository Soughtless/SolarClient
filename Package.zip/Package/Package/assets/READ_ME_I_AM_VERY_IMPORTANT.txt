 _    _  ___  ______ _   _ _____ _   _ _____ 
| |  | |/ _ \ | ___ \ \ | |_   _| \ | |  __ \
| |  | / /_\ \| |_/ /  \| | | | |  \| | |  \/
| |/\| |  _  ||    /| . ` | | | | . ` | | __ 
\  /\  / | | || |\ \| |\  |_| |_| |\  | |_\ \
 \/  \/\_| |_/\_| \_\_| \_/\___/\_| \_/\____/

(Sorry about the cheesy 90s ASCII art.)

Everything in this folder that does not belong here will be deleted.
This folder will be kept sync with the Launcher at every run.
If you wish to modify assets/resources in any way, use Resource Packs.


Ta,
Dinnerbone of Mojang